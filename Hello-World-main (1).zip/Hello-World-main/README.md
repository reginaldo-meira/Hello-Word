
![Descricao da sua imagem](https://raw.githubusercontent.com/silviosnjr/silviosnjr/main/Alura%20Start-Desenvolvimento%20web_%20ferramentas%20e%20orienta%C3%A7%C3%B5es%20para%20professores.png)

![](https://img.shields.io/github/license/alura-cursos/android-com-kotlin-personalizando-ui)

# Hello World

Projeto desenvolvido no curso de formação assíncrona para professores denominado "Desenvolvimento web: ferramentas e orientações para professores."

## 🔨 Funcionalidades do projeto

A criação da página proporciona um primeiro contato utilizando as linguagens HTML, CSS e JavaScript.

## 🎨Protótipo

Você pode [acessar por aqui o protótipo no Figma](https://www.figma.com/file/P2RnuaKEOOeQdqXgcqhTzZ/Hello-Word%3A-Minha-primeira-p%C3%A1gina-para-web?type=design&node-id=0%3A1&mode=design&t=n7bFGUZqUt6kCtew-1)

## 📁 Acesso ao projeto

Você pode [baixar o código fonte do projeto](https://codeload.github.com/silviosnjr/Hello-World/zip/refs/heads/main).

## 🛠️ Abrir e rodar o projeto

Após baixar o projeto, você pode abrir com o Visual Studio Code. Para isso, na tela de launcher clique em:

## 📚 Mais informações do curso

Você pode [acessar o curso](https://cursos.alura.com.br/course/ferramentas-orientacoes-professores) que desenvolve o projeto desde o começo!